import 'dart:async';

import 'package:dynamic_color/dynamic_color.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:flixquest/models/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'constants/app_constants.dart';
import 'constants/theme_data.dart';
import 'functions/function.dart';
import 'provider/app_dependency_provider.dart';
import 'provider/recently_watched_provider.dart';
import 'provider/settings_provider.dart';
import 'screens/common/discover.dart';
import 'screens/common/bookmark_screen.dart';
import 'screens/common/search_view.dart';
import 'screens/user/user_info.dart';
import 'screens/user/user_state.dart';
import 'widgets/movie_widgets.dart';
import 'widgets/tv_widgets.dart';
import 'widgets/occasional_effect_overlay.dart';
import 'provider/bookmark_provider.dart';
import 'provider/offline_download_provider.dart';
import 'provider/wellness_provider.dart';
import 'services/in_app_messaging_service.dart';
import 'services/deep_link_dispatcher.dart';
import 'services/home_widget_service.dart';
import 'services/recently_watched_sync_service.dart';
import 'services/app_session_state_store.dart';
import 'screens/common/downloads_screen.dart';
import 'tv/platform/device_presentation.dart';
import 'tv/widgets/tv_update_gate.dart';

class FlixQuest extends StatefulWidget {
  const FlixQuest(
      {required this.settingsProvider,
      required this.recentProvider,
      required this.bookmarkProvider,
      required this.appDependencyProvider,
      required this.devicePresentation,
      super.key});

  final SettingsProvider settingsProvider;
  final RecentProvider recentProvider;
  final BookmarkProvider bookmarkProvider;
  final AppDependencyProvider appDependencyProvider;
  final DevicePresentation devicePresentation;

  @override
  State<FlixQuest> createState() => _FlixQuestState();
}

class _FlixQuestState extends State<FlixQuest>
    with ChangeNotifier, WidgetsBindingObserver {
  Timer? _widgetRefreshDebounce;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WellnessProvider.instance.addListener(_scheduleLocalWidgetRefresh);
    widget.bookmarkProvider.addListener(_scheduleLocalWidgetRefresh);
    fileDelete();
    InAppMessagingService.initialize();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      DeepLinkDispatcher.onAppReady();
      unawaited(_refreshHomeWidgets());
    });
  }

  void _scheduleLocalWidgetRefresh() {
    _widgetRefreshDebounce?.cancel();
    _widgetRefreshDebounce = Timer(const Duration(seconds: 3), () {
      unawaited(HomeWidgetService.instance.refreshLocal(
        wellness: WellnessProvider.instance,
        bookmarks: widget.bookmarkProvider,
      ));
    });
  }

  Future<void> _refreshHomeWidgets() => HomeWidgetService.instance.refreshAll(
        settings: widget.settingsProvider,
        dependencies: widget.appDependencyProvider,
        wellness: WellnessProvider.instance,
        bookmarks: widget.bookmarkProvider,
      );

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
       unawaited(RecentlyWatchedSyncService.instance.flushPending());
      return;
    }
    DeepLinkDispatcher.onAppReady();
    unawaited(_refreshHomeWidgets());
    unawaited(RecentlyWatchedSyncService.instance.autoSyncIfSignedIn());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    WellnessProvider.instance.removeListener(_scheduleLocalWidgetRefresh);
    widget.bookmarkProvider.removeListener(_scheduleLocalWidgetRefresh);
    _widgetRefreshDebounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // SystemChrome.setPreferredOrientations([
    //   isTablet(context)
    //       ? DeviceOrientation.landscapeLeft
    //       : DeviceOrientation.portraitUp,
    // ]);
    return MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) {
            return widget.settingsProvider;
          }),
          ChangeNotifierProvider(create: (_) {
            return widget.recentProvider;
          }),
          ChangeNotifierProvider(create: (_) {
            return widget.bookmarkProvider;
          }),
          ChangeNotifierProvider(create: (_) {
            return widget.appDependencyProvider;
          }),
          ChangeNotifierProvider(
            create: (_) => OfflineDownloadProvider()..initialize(),
          ),
          ChangeNotifierProvider.value(value: WellnessProvider.instance),
        ],
        child:
            Consumer3<SettingsProvider, RecentProvider, AppDependencyProvider>(
                builder: (context, settingsProvider, recentProvider,
                    appDependencyProvider, snapshot) {
          return DynamicColorBuilder(
            builder: (lightDynamic, darkDynamic) {
              final isDarkTheme = settingsProvider.appTheme == 'dark' ||
                  settingsProvider.appTheme == 'amoled';
              final palette = AppColorsList().appColors(
                isDarkTheme,
                customColor: settingsProvider.customAppColor > 0
                    ? settingsProvider.customAppColor
                    : null,
              );
              final selectedAppColor = palette.firstWhere(
                (color) => color.index == settingsProvider.appColorIndex,
                orElse: () => palette.first,
              );
              final appTheme = Styles.themeData(
                appThemeMode: settingsProvider.appTheme,
                isM3Enabled: settingsProvider.isMaterial3Enabled,
                lightDynamicColor: lightDynamic,
                darkDynamicColor: darkDynamic,
                context: context,
                appColor: selectedAppColor,
                occasionalTheme: appDependencyProvider.activeOccasionalTheme,
                ambientColor: appDependencyProvider.activeAmbientColor,
              );
              unawaited(
                HomeWidgetService.instance.syncResolvedTheme(appTheme),
              );
              return MaterialApp(
                restorationScopeId: 'flixquest',
                navigatorKey: InAppMessagingService.navigatorKey,
                localizationsDelegates: context.localizationDelegates,
                supportedLocales: context.supportedLocales,
                locale: context.locale,
                debugShowCheckedModeBanner: false,
                builder: (context, child) =>
                    AnnotatedRegion<SystemUiOverlayStyle>(
                  value: SystemUiOverlayStyle(
                    systemNavigationBarColor: Colors.transparent,
                    systemNavigationBarDividerColor: Colors.transparent,
                    systemNavigationBarIconBrightness:
                        isDarkTheme ? Brightness.light : Brightness.dark,
                    systemNavigationBarContrastEnforced: false,
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (widget.devicePresentation ==
                          DevicePresentation.television)
                        TvUpdateGate(child: child ?? const SizedBox.shrink())
                      else
                        child ?? const SizedBox.shrink(),
                      if (widget.devicePresentation !=
                          DevicePresentation.television)
                        OccasionalEffectOverlay(
                          theme: appDependencyProvider.activeOccasionalTheme,
                          enabled:
                              appDependencyProvider.shouldShowOccasionalEffects,
                          visibilityListenable: appDependencyProvider,
                          visibilityResolver: () =>
                              appDependencyProvider.shouldShowOccasionalEffects,
                        ),
                    ],
                  ),
                ),
                theme: appTheme,
                home: UserState(
                  devicePresentation: widget.devicePresentation,
                ),
              );
            },
          );
        }));
  }
}

class FlixQuestHomePage extends StatefulWidget {
  const FlixQuestHomePage({
    super.key,
  });

  @override
  State<FlixQuestHomePage> createState() => _FlixQuestHomePageState();
}

class _FlixQuestHomePageState extends State<FlixQuestHomePage>
    with SingleTickerProviderStateMixin, RestorationMixin {
  static const _destinationIds = <String>[
    'movies',
    'series',
    'discover',
    'downloads',
    'profile',
  ];

  late final AppSessionStateStore _sessionState;
  late final RestorableString _selectedDestinationId;

  @override
  String get restorationId => 'handheld_home';

  @override
  void initState() {
    super.initState();
    _sessionState = AppSessionStateStore(sharedPrefsSingleton);
    final defaultHome =
        Provider.of<SettingsProvider>(context, listen: false).defaultValue;
    final defaultDestinationId = defaultHome == 3
        ? 'profile'
        : defaultHome >= 0 && defaultHome < _destinationIds.length
            ? _destinationIds[defaultHome]
            : 'movies';
    _selectedDestinationId = RestorableString(
      _sessionState.handheldDestination ?? defaultDestinationId,
    );
    WidgetsBinding.instance.addPostFrameCallback(
      (_) {
        Provider.of<SettingsProvider>(context, listen: false)
            .analytics
            .trackNavigation(
              destination: _selectedDestinationId.value,
              surface: 'standard',
              source: 'restored',
            );
      },
    );
  }

  @override
  void restoreState(RestorationBucket? oldBucket, bool initialRestore) {
    registerForRestoration(
      _selectedDestinationId,
      'selected_destination',
    );
    if (!_destinationIds.contains(_selectedDestinationId.value)) {
      _selectedDestinationId.value = 'movies';
    }
  }

  @override
  void dispose() {
    _selectedDestinationId.dispose();
    super.dispose();
  }

  void _selectDestination(int index) {
    final destinationId = _destinationIds[index];
    if (_selectedDestinationId.value == destinationId) return;
    setState(() {
      _selectedDestinationId.value = destinationId;
    });
    Provider.of<SettingsProvider>(context, listen: false)
        .analytics
        .trackNavigation(destination: destinationId, surface: 'standard');
    unawaited(_sessionState.rememberHandheldDestination(destinationId));
  }

  @override
  Widget build(BuildContext context) {
    final lang = Provider.of<SettingsProvider>(context).appLanguage;
    final colorScheme = Theme.of(context).colorScheme;
    final selectedIndex = _destinationIds.indexOf(
      _selectedDestinationId.value,
    );
    return Scaffold(
        // Keep the page surface behind the floating navigation bar and the
        // transparent Android gesture-navigation area.
        extendBody: true,
        bottomNavigationBar: Align(
          heightFactor: 1,
          alignment: Alignment.bottomCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: Container(
              margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                color: Theme.of(context).scaffoldBackgroundColor,
                border: Border.all(
                  color: colorScheme.onSurface.withValues(alpha: 0.08),
                ),
                boxShadow: [
                  BoxShadow(
                    blurRadius: 28,
                    offset: const Offset(0, 10),
                    color: Colors.black.withValues(alpha: .18),
                  )
                ],
              ),
              child: SafeArea(
                minimum: const EdgeInsets.symmetric(vertical: 4),
                child: NavigationBar(
                  height: 66,
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  indicatorColor: colorScheme.primary.withValues(alpha: 0.14),
                  labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
                  selectedIndex: selectedIndex,
                  onDestinationSelected: _selectDestination,
                  destinations: [
                    NavigationDestination(
                      icon: Icon(PhosphorIcons.house()),
                      selectedIcon: Icon(
                          PhosphorIcons.house(PhosphorIconsStyle.fill),
                          color: colorScheme.primary),
                      label: tr('movies'),
                    ),
                    NavigationDestination(
                      icon: Icon(PhosphorIcons.television()),
                      selectedIcon: Icon(
                          PhosphorIcons.television(PhosphorIconsStyle.fill),
                          color: colorScheme.primary),
                      label: tr('tv_series'),
                    ),
                    NavigationDestination(
                      icon: Icon(PhosphorIcons.compass()),
                      selectedIcon: Icon(
                          PhosphorIcons.compass(PhosphorIconsStyle.fill),
                          color: colorScheme.primary),
                      label: tr('discover'),
                    ),
                    NavigationDestination(
                      icon: Icon(PhosphorIcons.downloadSimple()),
                      selectedIcon: Icon(
                          PhosphorIcons.downloadSimple(PhosphorIconsStyle.fill),
                          color: colorScheme.primary),
                      label: 'Downloads',
                    ),
                    NavigationDestination(
                      icon: Icon(PhosphorIcons.user()),
                      selectedIcon: Icon(
                          PhosphorIcons.user(PhosphorIconsStyle.fill),
                          color: colorScheme.primary),
                      label: tr('profile'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        body: SafeArea(
          top: false,
          left: false,
          right: false,
          child: IndexedStack(
            index: selectedIndex,
            children: <Widget>[
              MainMoviesDisplay(
                onBookmarksPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const BookmarkScreen(),
                    ),
                  );
                },
                onSearchPressed: () {
                  showSearch(
                    context: context,
                    delegate: Search(
                      includeAdult:
                          Provider.of<SettingsProvider>(context, listen: false)
                              .isAdult,
                      lang: lang,
                    ),
                  );
                },
              ),
              MainTVDisplay(
                onBookmarksPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const BookmarkScreen(),
                    ),
                  );
                },
                onSearchPressed: () {
                  showSearch(
                    context: context,
                    delegate: Search(
                      includeAdult:
                          Provider.of<SettingsProvider>(context, listen: false)
                              .isAdult,
                      lang: lang,
                    ),
                  );
                },
              ),
              const DiscoverPage(),
              const DownloadsScreen(embedded: true),
              const UserInfo()
            ],
          ),
        ));
  }
}

/*

String? appVersion = _remoteConfig.getString('latest_version');
      SharedPreferences sharedPrefsSingleton = await SharedPreferences.getInstance();
      String? ignoreVersion = sharedPrefsSingleton.getString('ignore_version') ?? '';
      if (mounted &&
          appVersion != currentAppVersion &&
          (ignoreVersion == '' || ignoreVersion != currentAppVersion)) {
        showBottomSheet(
          context: context,
          builder: (context) {
            return Builder(
              builder: (BuildContext innerContext) {
                return UpdateBottom(
                  appVersion: appVersion,
                  ignoreVersion: ignoreVersion,
                  sharedPrefsSingleton: sharedPrefsSingleton,
                );
              },
            );
          },
        );
      }


*/
