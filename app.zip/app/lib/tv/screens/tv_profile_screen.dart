import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../services/auth_navigation_service.dart';
import '../../services/flixquest_auth_service.dart';
import '../../services/auth_session_controller.dart';
import '../app/tv_design.dart';
import '../focus/tv_focusable.dart';
import '../widgets/tv_dialog.dart';

class TvProfileScreen extends StatelessWidget {
  const TvProfileScreen({required this.metrics, super.key});

  final TvShellMetrics metrics;

  @override
  Widget build(BuildContext context) {
    final user = AuthSessionController.instance.currentUser;
    if (user == null || user.isAnonymous) {
      return _ProfileLayout(
        metrics: metrics,
        name: 'Guest',
        subtitle: 'Local watchlist and browsing session',
        profileId: 0,
        onSignOut: () => _confirmSignOut(context),
      );
    }

    return _ProfileLayout(
      metrics: metrics,
      name: user.displayName ?? 'FlixQuest member',
      subtitle: user.email ?? 'Signed in',
      profileId: 0,
      onSignOut: () => _confirmSignOut(context),
    );
  }

  Future<void> _confirmSignOut(BuildContext context) async {
    await showTvDialog<void>(
      context: context,
      title: 'Sign out?',
      content: const Text(
        'You will return to the FlixQuest TV welcome screen.',
      ),
      actions: <TvDialogAction>[
        TvDialogAction(
          label: 'Cancel',
          autofocus: true,
          onPressed: () => Navigator.of(context).pop(),
        ),
        TvDialogAction(
          label: 'Sign out',
          isPrimary: true,
          onPressed: () async {
            Navigator.of(context).pop();
            await FlixQuestAuthService.signOutGoogle();
            await FlixQuestAuthService().signOut();
            if (context.mounted) {
              await AuthNavigationService.returnToSignedOutRoot(context);
            }
          },
        ),
      ],
    );
  }
}

class _ProfileLayout extends StatelessWidget {
  const _ProfileLayout({
    required this.metrics,
    required this.name,
    required this.subtitle,
    required this.profileId,
    required this.onSignOut,
    this.photoUrl,
    this.loading = false,
  });

  final TvShellMetrics metrics;
  final String name;
  final String subtitle;
  final int profileId;
  final String? photoUrl;
  final VoidCallback onSignOut;
  final bool loading;

  Widget _profileImage({
    required ColorScheme colors,
    required double size,
  }) {
    final fallback = Container(
      width: size,
      height: size,
      color: colors.surfaceContainerHighest,
      child: Icon(
        PhosphorIcons.user(),
        color: colors.onSurfaceVariant,
        size: 54,
      ),
    );
    final url = photoUrl?.trim() ?? '';
    final image = url.isEmpty
        ? Image.asset(
            'assets/images/profiles/${profileId.clamp(0, 149)}.png',
            width: size,
            height: size,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => fallback,
          )
        : Image.network(
            url,
            width: size,
            height: size,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => fallback,
          );
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: image,
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: EdgeInsets.all(metrics.contentPadding),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(PhosphorIcons.userCircle(), color: colors.primary, size: 32),
              const SizedBox(width: 13),
              Text(
                'Profile',
                style: TextStyle(
                  color: colors.onSurface,
                  fontFamily: 'FigtreeSB',
                  fontSize: 34,
                ),
              ),
            ],
          ),
          const Spacer(),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 680),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: TvDesign.surfaceFor(context, emphasis: 0.025),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: colors.outlineVariant.withValues(alpha: 0.45),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.all(metrics.compact ? 26 : 38),
                  child: Row(
                    children: <Widget>[
                      _profileImage(
                        colors: colors,
                        size: metrics.compact ? 110 : 146,
                      ),
                      const SizedBox(width: 30),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            if (loading)
                              const LinearProgressIndicator()
                            else ...<Widget>[
                              Text(
                                name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: colors.onSurface,
                                  fontFamily: 'FigtreeSB',
                                  fontSize: metrics.compact ? 30 : 38,
                                ),
                              ),
                              const SizedBox(height: 7),
                              Text(
                                subtitle,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: colors.onSurfaceVariant,
                                  fontSize: metrics.compact ? 18 : 21,
                                ),
                              ),
                            ],
                            const SizedBox(height: 27),
                            TvFocusable(
                              semanticLabel: 'Sign out',
                              onActivate: onSignOut,
                              focusScale: 1.025,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 22,
                                  vertical: 14,
                                ),
                                decoration: BoxDecoration(
                                  color: colors.errorContainer,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Icon(PhosphorIcons.signOut(),
                                        color: colors.onErrorContainer),
                                    const SizedBox(width: 10),
                                    Text(
                                      'Sign out',
                                      style: TextStyle(
                                        color: colors.onErrorContainer,
                                        fontFamily: 'FigtreeSB',
                                        fontSize: 19,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}
