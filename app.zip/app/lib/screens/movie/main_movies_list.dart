import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../functions/network.dart';
import '../../models/movie.dart';
import '../../provider/app_dependency_provider.dart';
import '../../provider/settings_provider.dart';
import '../../ui_components/movie_ui_components.dart';
import '../../widgets/common_widgets.dart';
import '../../ui_components/app_ui_components.dart';
import '../common/search_view.dart';
import '../../video_providers/scraper_api.dart';
import '../../widgets/hosted_ads_banner.dart';

class MainMoviesList extends StatefulWidget {
  final String api;
  final bool? includeAdult;
  final String discoverType;
  final bool isTrending;
  final String title;
  const MainMoviesList({
    super.key,
    required this.api,
    required this.discoverType,
    required this.isTrending,
    required this.includeAdult,
    required this.title,
  });
  @override
  MainMoviesListState createState() => MainMoviesListState();
}

class MainMoviesListState extends State<MainMoviesList> {
  List<Movie>? moviesList;
  final _scrollController = ScrollController();
  int pageNum = 2;
  bool isLoading = false;

  String _requestUrl({int? page}) {
    final uri = Uri.parse(widget.api);
    final queryParameters = Map<String, String>.from(uri.queryParameters);

    if (!widget.isTrending && widget.includeAdult != null) {
      queryParameters['include_adult'] = widget.includeAdult.toString();
    }
    if (page != null) {
      queryParameters['page'] = page.toString();
    }

    return uri.replace(queryParameters: queryParameters).toString();
  }

  void getMoreData() async {
    final isProxyEnabled =
        Provider.of<SettingsProvider>(context, listen: false).enableProxy;
    final proxyUrl =
        Provider.of<AppDependencyProvider>(context, listen: false).tmdbProxy;
    _scrollController.addListener(() async {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        setState(() {
          isLoading = true;
        });
        if (mounted) {
          fetchMovies(_requestUrl(page: pageNum), isProxyEnabled, proxyUrl)
              .then((value) {
            if (mounted) {
              setState(() {
                moviesList!.addAll(value);
                isLoading = false;
                pageNum++;
              });
            }
          });
        }
      }
    });
  }

  @override
  void initState() {
    super.initState();
    final isProxyEnabled =
        Provider.of<SettingsProvider>(context, listen: false).enableProxy;
    final proxyUrl =
        Provider.of<AppDependencyProvider>(context, listen: false).tmdbProxy;
    fetchMovies(_requestUrl(), isProxyEnabled, proxyUrl).then((value) {
      if (mounted) {
        setState(() {
          moviesList = value;
        });
      }
    });
    getMoreData();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeMode = Provider.of<SettingsProvider>(context).appTheme;
    final imageQuality = Provider.of<SettingsProvider>(context).imageQuality;
    final viewType = Provider.of<SettingsProvider>(context).defaultView;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('movie_type', namedArgs: {'t': widget.title})),
        actions: [
          IconButton(
            onPressed: _openSearch,
            icon: Icon(PhosphorIcons.magnifyingGlass()),
          ),
        ],
      ),
      body: moviesList == null && viewType == 'grid'
          ? moviesAndTVShowGridShimmer(themeMode)
          : moviesList == null && viewType == 'list'
              ? mainPageVerticalScrollShimmer(
                  themeMode: themeMode,
                  isLoading: isLoading,
                  scrollController: _scrollController)
              : moviesList!.isEmpty
                  ? AppEmptyState(
                      title: tr('movie_404'),
                      message: tr('no_result'),
                      icon: PhosphorIcons.filmStrip(),
                    )
                  : Column(
                      children: [
                        RemoteHostedAdsBanner(
                          placement: 'movie_list',
                          loadAds: () => ScraperApi(
                            context
                                .read<AppDependencyProvider>()
                                .flixquestAPIURL,
                          ).getAds(),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Column(
                              children: [
                                Expanded(
                                    child: viewType == 'grid'
                                        ? MovieGridView(
                                            scrollController: _scrollController,
                                            moviesList: moviesList,
                                            imageQuality: imageQuality,
                                            themeMode: themeMode)
                                        : MovieListView(
                                            scrollController: _scrollController,
                                            moviesList: moviesList,
                                            themeMode: themeMode,
                                            imageQuality: imageQuality)),
                              ],
                            ),
                          ),
                        ),
                        Visibility(
                            visible: isLoading,
                            child: const Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Center(child: LinearProgressIndicator()),
                            )),
                      ],
                    ),
    );
  }

  void _openSearch() {
    final settings = Provider.of<SettingsProvider>(context, listen: false);
    showSearch(
      context: context,
      delegate: Search(
        includeAdult: settings.isAdult,
        lang: settings.appLanguage,
      ),
    );
  }
}
